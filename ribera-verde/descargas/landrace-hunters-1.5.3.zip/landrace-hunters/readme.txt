=== Landrace Hunters ===
Version: 1.5.3
Autor: WOLFCADE

Juego «Landrace Hunters» (Godot 4.3, exportación web sin hilos) servido desde el plugin.

Instalar: Plugins → Añadir nuevo → Subir plugin → landrace-hunters-1.5.3.zip → Activar.
Jugar: /landrace-hunters/ (cambiable en Ajustes → Landrace Hunters).
Incrustar: [landrace_hunters alto="80vh"].

Se rehace con el juego de cada versión: node tools/wordpress.js en el repositorio (exporta index.pck de godot/).
Si el servidor no deja subir un archivo tan grande, descomprímelo y súbelo por FTP a wp-content/plugins/landrace-hunters/.
Fuentes: Atkinson Hyperlegible y Press Start 2P, licencia SIL OFL (game/OFL-*.txt).

Cambios
1.5.3 — Landrace Hunters 1.57 (Godot 0.47.0): la carga en la carretera y el título con más atrezo, el viaje de perfil, los tubos de las carpas con codos y los mandos más grandes, donde caen los pulgares.
1.5.2 — Landrace Hunters 1.55.2 (Godot 0.46.1): el que cuida las madres de la nave, delante de su carpa y no de la puerta de la habitación.
1.5.1 — El juego de hoy (Landrace Hunters 1.55.1, Godot 0.46.0): cada acción de cerca con sprites a mano (regar, abonar, esquejar, cosechar, fumar, dormir…), abrir con llave o clave, las carpas ordenables con su tubo de extracción a la ventana y cualquier mueble de la casa ordenable, con la puerta del sótano y la escalera del camarote siempre libres.
1.5.0 — El juego de hoy (Landrace Hunters 1.52.0, Godot 0.45.0): todo lo de la 1.44 a la 1.52 —el bajo de las setas entero, los negocios por dentro, sentarse y fumar, los locales a escala, el muelle de Puerto Viejo con los barcos, el piso franco y las obras, el club KAIA y la ley, el sótano, el tiempo y las estaciones en el móvil, la Ruderalis y las autoflorecientes—.
1.4.4 — Landrace Hunters 1.43.5 (Godot 0.37.5): cada nombre de chica con personaje chica y cada chico con chico (presidentes de los clubs, agenda, naveros, rivales y encargadas); exportar e importar la partida, escondidos en OPCIONES → COPIA DE SEGURIDAD.
1.4.3 — Lo probado en la web (1.2.1) en el plugin de hoy: la caché de página (Kuboplay Shield) ya no guarda la página del juego y se vacía al actualizar; al desactivar, la dirección deja de responder sin guardar los enlaces permanentes; al borrarlo no deja ajustes; el aviso de instalar se va solo a los 15 s. La música de la versión web, más ligera (el zip baja de 30 MB).
1.4.2 — Landrace Hunters 1.43.2 (Godot 0.37.2): con tu vehículo no pagas autobús, solo gasolina; el seguro y el impuesto de circulación al año y el taller por km (revisión y neumáticos).
1.4.1 — Landrace Hunters 1.43.1 (Godot 0.37.1): coches de juguete a la escala del protagonista, la moto como un scooter en el que vas sentado y todas las ruedas gordas y con llanta.
1.4.0 — El juego de hoy (Landrace Hunters 1.43.0, Godot 0.37.0): el concesionario del barrio alto (moto, utilitario, berlina y superdeportivo, con seguro, gasolina y controles), las bandejas de clones de la nave, el calendario y el mapa centrados, y todo lo anterior.
1.3.0 — El juego de hoy (Landrace Hunters 1.42.0, Godot 0.36.0): calendario desde el lunes 20 de abril de 2026, mapa de la comarca en el móvil, la nave con opción a compra, la nave por ciclos, la caja por tarros, el carro de esquejes, la nevera ampliable, las extracciones a la vista, la música por zonas y todo lo anterior.
1.2.1 — La caché de página (Kuboplay Shield) ya no guarda la página del juego: tras actualizar se ve la versión nueva al momento. Al desactivar, la dirección deja de responder sin tener que guardar los enlaces permanentes. Al borrarlo no deja ajustes en la base de datos. El aviso de instalar se va solo a los 15 s.
1.2.0 — Instalar como app en el móvil: en Android sale un aviso con botón «Instalar» (o, si el navegador no lo ofrece, cómo hacerlo desde el menú ⋮); en iPhone, un aviso que explica Compartir → «Añadir a pantalla de inicio». Abierto desde el icono va sin barras. El aviso se cierra con × y no vuelve en 7 días.
1.1.0 — Pantalla completa: al primer toque el juego ocupa toda la pantalla, sin barra del navegador, y se pone en horizontal (Android). En vertical sale «Gira el móvil». La página se puede instalar con «Añadir a pantalla de inicio» y abre sin barras (única vía en iPhone). Se apaga en Ajustes → Landrace Hunters.
1.0.0 — Primera versión.
